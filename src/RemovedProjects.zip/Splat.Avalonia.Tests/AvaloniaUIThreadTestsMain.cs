﻿namespace ReactiveUI.Avalonia.Tests
{
    public class AvaloniaUIThreadTestsMain
    {
        ////[Fact]
        ////public void Test1()
        ////{
            ////AppBuilder.Configure<App>()
            ////    .UsePlatformDetect()
            ////    .UseReactiveUI()
            ////    .LogToTrace()
            ////    .SetupWithoutStarting();
            ////Assert.IsType<AvaloniaScheduler>(RxApp.MainThreadScheduler);
        ////}
    }
}
